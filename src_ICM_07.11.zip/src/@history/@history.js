import * as history from 'history';

export default history.createBrowserHistory();
// export default history.createBrowserHistory({
//     basename: '/', // Set your basename if needed
//     hashType: 'slash', // Use 'slash' to add hashbang ('#!/') in the URL
//   });
