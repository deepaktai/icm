// import { combineReducers } from '@reduxjs/toolkit';
// import fuse from './fuse';
// import i18n from './i18nSlice';
// import user from './userSlice';
// import prevail from './prevailSlice';
// import detail  from './detailSlice';
// import member from './memberSlice';
// import NewApplicationSlice from './NewApplicationSlice'
// import PastorSlice from './PastorSlice';

// const createReducer = (asyncReducers) => (state, action) => {
//   const combinedReducer = combineReducers({
//     fuse,
//     i18n,
//     user,
//     prevail,
//     detail,
//     member,
//     NewApplicationSlice,
//     PastorSlice,
//     ...asyncReducers,
//   });

//   /*
// 	Reset the redux store when user logged out
// 	 */
//   if (action.type === 'user/userLoggedOut') {
//     // state = undefined;
//   }

//   return combinedReducer(state, action);
// };

// export default createReducer;


import { combineReducers } from '@reduxjs/toolkit';
import fuse from './fuse';
import i18n from './i18nSlice';
import user from './userSlice';
import prevail from './prevailSlice';
import detail from './detailSlice';
import member from './memberSlice';
import NewApplicationSlice from './NewApplicationSlice';


const createReducer = (asyncReducers) => (state, action) => {
  const combinedReducer = combineReducers({
    fuse,
    i18n,
    user,
    prevail,
    detail,
    member,
    NewApplicationSlice, // Specify the slice name for NewApplicationSlice
    // pastor: PastorSlice.reducer, // Specify the slice name for PastorSlice
    ...asyncReducers,
  });

  if (action.type === 'user/userLoggedOut') {
    // Reset the state when the user logs out
    state = undefined;
  }

  return combinedReducer(state, action);
};

export default createReducer;

