// tabLabels.js
export const TAB_LABELS = {
  application: 'Application',
  approvallist: 'Approval List',
  communitylist: 'Community List',
  rowdatadetail: 'Row Data Details',
};
