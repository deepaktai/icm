import React from 'react';
import CommunityFilter from './data-component/CommunityFilter';
import CommunityTable from './data-component/CommunityTable';

function CommunityList() {
  return (
    <div>
     <CommunityFilter/>
     <CommunityTable/>
    </div>
  )
}

export default CommunityList