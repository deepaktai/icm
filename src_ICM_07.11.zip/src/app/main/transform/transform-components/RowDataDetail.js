import React from 'react'
import ReportDetail from './data-component/ReportDetail'

function RowDataDetail() {
  return (
    <div>
      <ReportDetail/>
    </div>
  )
}

export default RowDataDetail